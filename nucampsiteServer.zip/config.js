module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '887429068908043',
        clientSecret: '1008726f9c5f7712b87a34be17000745'
    }
}